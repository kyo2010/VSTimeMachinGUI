java -classpath Updater.jar updater.Updater
